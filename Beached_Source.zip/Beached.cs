﻿// BEACHED MOD - By VirtuaVirtue
// Don't use this code unless you're trying to make it better cause it's pretty bad and C# is my weakest language.

// Removes (most) liquid from rain world.

using System;
using System.Collections.Generic;
using System.Security;
using System.Security.Permissions;
using UnityEngine;
using RWCustom;
using BepInEx;
using System.Globalization;

#pragma warning disable CS0618

[module: UnverifiableCode]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]

namespace Beached;

[BepInPlugin("VirtuaVirtue.Beached", "Beached", "1.0.0")]
public partial class Beached : BaseUnityPlugin
{

        // COMPUTE STRING HASH - Computes String Hash or something IDK I stole this from the source since I couldn't find out how to access the class directly
    public static uint ComputeStringHash(string s)
    {
        uint num = 0;
        if (s != null)
        {
            num = 2166136261U;
            for (int i = 0; i < s.Length; i++)
            {
                num = ((uint)s[i] ^ num) * 16777619U;
            }
        }
        return num;
    }

        // Mod Enabled
    private void OnEnable()
    {
        On.RainWorld.OnModsInit += RainWorldOnOnModsInit;
    }

        // Is Initialized Bool
    private bool IsInit;
        // Mods Initialized - Runs the hooks
    private void RainWorldOnOnModsInit(On.RainWorld.orig_OnModsInit orig, RainWorld self)
    {
        orig(self);

            // Try-Catch
        try
        {
                // Hooks
            if (IsInit) return;
            On.Room.LoadFromDataString += Room_LoadFromDataString;
            On.Room.SlugcatGamemodeUniqueRoomSettings += Room_SlugcatGamemodeUniqueRoomSettings;

            IsInit = true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex);
            throw;
        }
    }

        // UNIQUE ROOM SETTINGS - Mainly used to disable water flux here
    private void Room_SlugcatGamemodeUniqueRoomSettings(On.Room.orig_SlugcatGamemodeUniqueRoomSettings orig, Room self, RainWorldGame game)
    {
        self.waterFlux = null;
        orig(self, game);
    }

        // LOAD ROOM DATA FROM STRING - Disables water and waterfalls
        // Commented out code is responsible for water
    private void Room_LoadFromDataString(On.Room.orig_LoadFromDataString orig, Room self, string[] lines)
    {
        RoomPreprocessor.VersionFix(ref lines);
        string[] array = lines[1].Split(new char[]
        {
            '*'
        });
        /*if (lines[1].Split(new char[]
        {
            '|'
        })[1] == "-1")
        {*/
            self.water = false;
            self.defaultWaterLevel = -1;
            self.floatWaterLevel = float.MinValue;
        /*}
        else
        {
            self.water = true;
            self.defaultWaterLevel = Convert.ToInt32(lines[1].Split(new char[]
            {
                '|'
            })[1], CultureInfo.InvariantCulture);
            self.floatWaterLevel = self.MiddleOfTile(new IntVector2(0, self.defaultWaterLevel)).y;
            self.waterInFrontOfTerrain = (Convert.ToInt32(lines[1].Split(new char[]
            {
                '|'
            })[2], CultureInfo.InvariantCulture) == 1);
        }*/
        array = lines[1].Split(new char[]
        {
            '|'
        })[0].Split(new char[]
        {
            '*'
        });
        self.Width = Convert.ToInt32(array[0], CultureInfo.InvariantCulture);
        self.Height = Convert.ToInt32(array[1], CultureInfo.InvariantCulture);
        string[] array2 = lines[2].Split(new char[]
        {
            '|'
        })[0].Split(new char[]
        {
            '*'
        });
        self.lightAngle = new Vector2(Convert.ToSingle(array2[0], CultureInfo.InvariantCulture), Convert.ToSingle(array2[1], CultureInfo.InvariantCulture));
        string[] array3 = lines[3].Split(new char[]
        {
            '|'
        });
        self.cameraPositions = new Vector2[array3.Length];
        for (int i = 0; i < array3.Length; i++)
        {
            self.cameraPositions[i] = new Vector2(Convert.ToSingle(array3[i].Split(new char[]
            {
                ','
            })[0], CultureInfo.InvariantCulture), -(800f - (float)self.Height * 20f + Convert.ToSingle(array3[i].Split(new char[]
            {
                ','
            })[1])));
        }
        self.DefaultTile = null;
        if (self.world != null && self.game != null && self.abstractRoom.firstTimeRealized && (!self.game.IsArenaSession || self.game.GetArenaGameSession.GameTypeSetup.levelItems))
        {
            string[] array4 = lines[5].Split(new char[]
            {
                '|'
            });
            for (int j = 0; j < array4.Length - 1; j++)
            {
                IntVector2 intVector = new IntVector2(Convert.ToInt32(array4[j].Split(new char[]
                {
                    ','
                })[1], CultureInfo.InvariantCulture) - 1, self.Height - Convert.ToInt32(array4[j].Split(new char[]
                {
                    ','
                })[2], CultureInfo.InvariantCulture));
                bool flag;
                if (Convert.ToInt32(array4[j].Split(new char[]
                {
                    ','
                })[0], CultureInfo.InvariantCulture) == 1)
                {
                    flag = (UnityEngine.Random.value < 0.6f);
                }
                else
                {
                    flag = (UnityEngine.Random.value < 0.75f);
                }
                if (flag)
                {
                    EntityID newID = self.game.GetNewID(-self.abstractRoom.index);
                    int num = Convert.ToInt32(array4[j].Split(new char[]
                    {
                        ','
                    })[0], CultureInfo.InvariantCulture);
                    if (num != 0)
                    {
                        if (num == 1)
                        {
                            self.abstractRoom.AddEntity(new AbstractSpear(self.world, null, new WorldCoordinate(self.abstractRoom.index, intVector.x, intVector.y, -1), newID, false));
                        }
                    }
                    else
                    {
                        self.abstractRoom.AddEntity(new AbstractPhysicalObject(self.world, AbstractPhysicalObject.AbstractObjectType.Rock, null, new WorldCoordinate(self.abstractRoom.index, intVector.x, intVector.y, -1), newID));
                    }
                }
            }
        }
        self.Tiles = new Room.Tile[self.Width, self.Height];
        for (int k = 0; k < self.Width; k++)
        {
            for (int l = 0; l < self.Height; l++)
            {
                self.Tiles[k, l] = new Room.Tile(k, l, Room.Tile.TerrainType.Air, false, false, false, 0, ((l <= self.defaultWaterLevel) ? 1 : 0) + ((l == self.defaultWaterLevel) ? 1 : 0));
            }
        }
        List<IntVector2> list = new List<IntVector2>();
        List<IntVector2> list2 = new List<IntVector2>();
        List<int> list3 = new List<int>();
        int num2 = -1;
        List<IntVector2> list4 = new List<IntVector2>();
        IntVector2 intVector2 = new IntVector2(0, self.Height - 1);
        List<IntVector2> list5 = new List<IntVector2>();
        string[] array5 = lines[11].Split(new char[]
        {
            '|'
        });
        for (int m = 0; m < array5.Length - 1; m++)
        {
            string[] array6 = array5[m].Split(new char[]
            {
                ','
            });
            self.Tiles[intVector2.x, intVector2.y].Terrain = (Room.Tile.TerrainType)int.Parse(array6[0], NumberStyles.Any, CultureInfo.InvariantCulture);
            for (int n = 1; n < array6.Length; n++)
            {
                string text = array6[n];
                if (text != null)
                {
                    uint num3 = ComputeStringHash(text);
                    if (num3 <= 839689206U)
                    {
                        if (num3 <= 501951850U)
                        {
                            if (num3 != 468396612U)
                            {
                                if (num3 != 485174231U)
                                {
                                    if (num3 == 501951850U)
                                    {
                                        if (text == "12")
                                        {
                                            self.Tiles[intVector2.x, intVector2.y].shortCut = 5;
                                        }
                                    }
                                }
                                else if (text == "11")
                                {
                                    list5.Add(intVector2);
                                }
                            }
                            else if (text == "10")
                            {
                                list2.Add(intVector2);
                            }
                        }
                        else if (num3 != 806133968U)
                        {
                            if (num3 != 822911587U)
                            {
                                if (num3 == 839689206U)
                                {
                                    if (text == "7")
                                    {
                                        Room.AddHiveTile(ref list, ref list3, ref num2, intVector2);
                                        self.Tiles[intVector2.x, intVector2.y].hive = true;
                                    }
                                }
                            }
                            else if (text == "4")
                            {
                                self.Tiles[intVector2.x, intVector2.y].shortCut = 2;
                            }
                        }
                        else if (text == "5")
                        {
                            self.Tiles[intVector2.x, intVector2.y].shortCut = 3;
                        }
                    }
                    else if (num3 <= 906799682U)
                    {
                        if (num3 != 856466825U)
                        {
                            if (num3 != 873244444U)
                            {
                                if (num3 == 906799682U)
                                {
                                    if (text == "3")
                                    {
                                        if (self.Tiles[intVector2.x, intVector2.y].shortCut < 1)
                                        {
                                            self.Tiles[intVector2.x, intVector2.y].shortCut = 1;
                                        }
                                    }
                                }
                            }
                            else if (text == "1")
                            {
                                self.Tiles[intVector2.x, intVector2.y].verticalBeam = true;
                            }
                        }
                        else if (text == "6")
                        {
                            self.Tiles[intVector2.x, intVector2.y].wallbehind = true;
                        }
                    }
                    else if (num3 != 923577301U)
                    {
                        if (num3 != 1007465396U)
                        {
                            if (num3 == 1024243015U)
                            {
                                if (text == "8")
                                {
                                    list4.Add(intVector2);
                                }
                            }
                        }
                        else if (text == "9")
                        {
                            self.Tiles[intVector2.x, intVector2.y].shortCut = 4;
                        }
                    }
                    else if (text == "2")
                    {
                        self.Tiles[intVector2.x, intVector2.y].horizontalBeam = true;
                    }
                }
            }
            intVector2.y--;
            if (intVector2.y < 0)
            {
                intVector2.x++;
                intVector2.y = self.Height - 1;
            }
        }
        if (list2.Count > 0)
        {
            self.garbageHoles = list2.ToArray();
        }
        if (num2 > -1)
        {
            self.hives = new IntVector2[num2 + 1][];
            for (int num4 = 0; num4 <= num2; num4++)
            {
                int num5 = 0;
                for (int num6 = 0; num6 < list3.Count; num6++)
                {
                    if (list3[num6] == num4)
                    {
                        num5++;
                    }
                }
                self.hives[num4] = new IntVector2[num5];
                int num7 = 0;
                for (int num8 = 0; num8 < list3.Count; num8++)
                {
                    if (list3[num8] == num4)
                    {
                        self.hives[num4][num7] = list[num8];
                        num7++;
                    }
                }
            }
        }
        else
        {
            self.hives = new IntVector2[0][];
        }
        //List<WaterFall> list6 = new List<WaterFall>();
        while (list4.Count > 0)
        {
            IntVector2 intVector3 = list4[0];
            for (int num9 = 0; num9 < list4.Count; num9++)
            {
                intVector3 = list4[num9];
                if (!list4.Contains(intVector3 + new IntVector2(-1, 0)) && !list4.Contains(intVector3 + new IntVector2(0, 1)))
                {
                    break;
                }
            }
            bool flag2 = list4.Contains(intVector3 + new IntVector2(0, -1));
            int num10 = 0;
            int num11 = intVector3.x;
            while (num11 < self.TileWidth && list4.Contains(new IntVector2(num11, intVector3.y)) && list4.Contains(new IntVector2(num11, intVector3.y - 1)) == flag2)
            {
                num10++;
                list4.Remove(new IntVector2(num11, intVector3.y));
                if (flag2)
                {
                    list4.Remove(new IntVector2(num11, intVector3.y - 1));
                }
                num11++;
            }
            //list6.Add(new WaterFall(self, intVector3, flag2 ? 1f : 0.5f, num10));
        }
        /*self.waterFalls = list6.ToArray();
        for (int num12 = 0; num12 < self.waterFalls.Length; num12++)
        {
            self.AddObject(self.waterFalls[num12]);
        }*/
        if (list5.Count > 0)
        {
            self.AddObject(new WormGrass(self, list5));
        }
        self.Loaded();
    }
}